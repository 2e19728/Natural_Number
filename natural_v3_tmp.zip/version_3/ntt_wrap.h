// ntt_wrap.h - wrap-corrected ("one size shorter") NTT multiplication for version_2.
//
// Why
// ---
// get_NTT_scale() forces 2^(scale-1) < len1+len2-2 <= 2^scale, so the transform is the next
// power of two of ~2n: for operands just above a power-of-two boundary the transform is half
// empty, and because the transform cost is N*log N (and load/CRT are O(N)) the time jumps by
// up to ~1.7x for a 0.2% larger input.  Measured here (balanced, best of 5): n=1024 -> 114 us,
// n=1026 -> 192 us with the version_1 schedule.
//
// How
// ---
// A cyclic convolution of length N yields c_i = p_i + p_{i+N} (p = true linear convolution).
// For len1+len2-1 <= 2N only the first w = len1+len2-1-N coefficients are aliased, and those
// only involve the top w+1 limbs of each operand: with A' = floor(a / B^(len1-w-1)),
// B' = floor(b / B^(len2-w-1)) (B = 2^64) and tau the convolution coefficients of A'*B',
//
//      p_{i+N} = tau_{w+1+i}                    for 0 <= i < w.
//
// With  C = sum_{i<N} c_i B^i   and   H = sum_{i<w} p_{i+N} B^i,  both exact integers,
//
//      C = (sum_{i<N} p_i B^i) + H        and      a*b = (sum_{i<N} p_i B^i) + B^N * H,
//
// therefore, with no per-coefficient correction at all,
//
//      a*b = C + (B^N - 1) * H                                          (*)
//
// Cost: one cyclic convolution of N = 2^(scale-1) points (3 transforms) plus a small product
// of (w+1)-limb operands for H (3 transforms of ~2(w+1) points).  When w is small - exactly
// in the "just above a power of two" band - the correction is nearly free, and (*) replaces
// version_1's 5 transforms of N points (its a0/a1 split) or 3 transforms of 2N points.
// Measured: n=1026 192 -> 128 us (1.50x), n=2052 393 -> 264 us (1.49x), n=4104 859 -> 559 us
// (1.54x).  Once the wrap reaches ~1/4 of N the correction product is as big as the main one,
// and the planner below keeps the version_1 path.
//
// Correctness notes
//   * C comes from crt(N) plus its two carry words, H from crt(w) plus its two carry words.
//     Both carry values are < 2^(64+log2(...)) < 2^128, so asmCRT's two carry words suffice.
//   * B^N * H >= H, so the subtraction in (*) never borrows out.
//   * all arithmetic before the CRT is on reduced residues in [0, mod).
//
// Verified by verify/mulcheck.cpp (shape grid; wrap on vs off vs Toom-22) and by
// verify/run.sh (byte-for-byte against version_0).

#pragma once

#include <cstdint>
#include <cstring>

#include "array_u64.h"
#include "ntt_workspace.h"

// Same formula as natural.h's get_NTT_scale(), duplicated here so this header does not depend
// on natural.h (the caller passes the same value in as `scale`).
inline int ntt_wrap_scale(uint64_t len1, uint64_t len2) {
	return 64 - std::countl_zero(len1 + len2 - 2);
}

// ---------------------------------------------------------------- cost model
// Units are "butterfly points": pt(M) = M * log2(M).
//   full  : 3 transforms of 2^scale
//   split : 5 transforms of 2^(scale-1)  (version_1's a0/a1 split, reuses one transform)
//   wrap  : 3 transforms of N + 3 transforms of the correction size, plus CRT/assembly
// The per-size constants are calibrated against verify/sawthooth.sh measurements; the planner
// only has to rank three options, and verify/mulcheck.cpp checks that the ranking is sane.
inline double ntt_pt_cost(uint64_t points) {
	return (double)points * (double)(64 - __builtin_clzll(points));
}

inline double ntt_full_cost(int scale) {
	uint64_t points = 1ull << scale;
	return 3.0 * ntt_pt_cost(points) + 3.0 * (double)points;      // + load/CRT, ~2 passes
}

inline double ntt_split_cost(int scale) {
	uint64_t points = 1ull << (scale - 1);
	return 5.0 * ntt_pt_cost(points) + 6.0 * (double)points;      // 2 x (load/CRT) + assembly
}

inline bool mul_ntt_wrap_applicable(uint64_t len1, uint64_t len2, int scale, uint64_t* N_out, uint64_t* w_out) {
	if (len1 == 0 || len2 == 0 || scale < 2)
		return false;
	uint64_t N = 1ull << (scale - 1);
	uint64_t w = len1 + len2 - 1 - N;                 // number of aliased coefficients
	if (len1 > N || len2 > N || w == 0 || len1 < w + 1 || len2 < w + 1)
		return false;
	if (N_out) *N_out = N;
	if (w_out) *w_out = w;
	return true;
}

inline double ntt_wrap_correction_cost(uint64_t w) {
	// H is the CRT of the w raw wrap coefficients; they come from a product of (w+1)-limb
	// slices, so its transform is get_NTT_scale(w+1, w+1), plus one more pass for crt(w).
	if (2 * (w + 1) - 2 < 1)
		return 0.0;
	uint64_t points = 1ull << ntt_wrap_scale(w + 1, w + 1);
	return 3.0 * ntt_pt_cost(points) + 4.0 * (double)points;
}

// version_2 switch: false reproduces the version_1 schedule exactly (for A/B testing)
inline bool ntt_wrap_enable = true;

// Safety margin on the planner: the cost model is calibrated, but a misprediction costs the
// whole speedup and more (measured: without the margin the planner picks wrap at 68-73% fill
// and loses 4-7%).  Wrap is therefore only taken when it is clearly cheaper.  With 0.90 the
// remaining mispredictions are ties (measured within +-1%).
inline constexpr double ntt_wrap_margin = 0.90;

inline bool ntt_wrap_preferred(uint64_t len1, uint64_t len2, int scale) {
	if (!ntt_wrap_enable)
		return false;
	uint64_t N, w;
	if (!mul_ntt_wrap_applicable(len1, len2, scale, &N, &w))
		return false;
	double cw = 3.0 * ntt_pt_cost(N) + 4.0 * (double)N + ntt_wrap_correction_cost(w);
	double cf = ntt_full_cost(scale);
	double cs = 1e300;
	uint64_t hi = len1 > len2 ? len1 : len2, lo = len1 > len2 ? len2 : len1;
	if (ntt_wrap_scale((hi + 1) >> 1, lo) != scale)        // version_1 takes the split here
		cs = ntt_split_cost(scale);
	return cw < ntt_wrap_margin * cf && cw < ntt_wrap_margin * cs;
}

// ---------------------------------------------------------------- the kernel
// dst = a * b, dst holds len1+len2 limbs, via (*) above.  The caller must have checked
// mul_ntt_wrap_applicable().
inline void mul_ntt_wrap(uint64_t* dst, const uint64_t* a, uint64_t len1, const uint64_t* b, uint64_t len2, int scale) {
	const uint64_t N = 1ull << (scale - 1);
	const uint64_t w = len1 + len2 - 1 - N;
	const uint64_t total = len1 + len2;

	// 1. C = sum_{i<N} c_i B^i, c from the length-N cyclic convolution of the operands
	ntt_workspace wa(a, len1, scale - 1), wb(b, len2, scale - 1);
	wa.ntt();
	wb.ntt();
	wa.mul(wa, wb);
	wa.intt();
	uint64_t cf = wa.crt(N);
	array_u64 C;
	C.resize(N + 2);
	uint64_t cn0 = N < wa.ntt_data[0].size ? N : wa.ntt_data[0].size;   // = N (bounded, for the compiler)
	memcpy(C.data, wa.ntt_data[0].data, sizeof(uint64_t) * cn0);
	C[N] = cf;
	C[N + 1] = wa.ntt_data[1][1];
	while (C.size > 1 && C[C.size - 1] == 0)
		C.size--;

	// 2. H = sum_{i<w} p_{i+N} B^i, the CRT of the raw wrap coefficients tau_{w+1+i}
	array_u64 H;
	uint64_t sl = len1 - (w + 1), sb = len2 - (w + 1);
	uint64_t Al = w + 1, Bl = w + 1;
	while (Al > 1 && a[sl + Al - 1] == 0)
		Al--;
	while (Bl > 1 && b[sb + Bl - 1] == 0)
		Bl--;
	if (Al + Bl < 3) {
		// both slices are single limbs: A'*B' has no coefficient at index >= w+1
		H.resize(1);
		H[0] = 0;
	}
	else {
		int st = ntt_wrap_scale(Al, Bl);
		ntt_workspace wt(a + sl, Al, st), wu(b + sb, Bl, st);
		wt.ntt();
		wu.ntt();
		wt.mul(wt, wu);
		wt.intt();
		uint64_t lim = wt.ntt_data[0].size;
		ntt_workspace hs;
		for (int i = 0; i < 3; i++) {
			hs.ntt_data[i].resize(w + 2);
			for (uint64_t k = 0; k < w; k++)
				hs.ntt_data[i][k] = (w + 1 + k) < lim ? wt.ntt_data[i][w + 1 + k] : 0;
		}
		uint64_t ch = hs.crt(w);
		H.resize(w + 2);
		uint64_t wn = w < hs.ntt_data[0].size ? w : hs.ntt_data[0].size;  // = w (bounded)
		memcpy(H.data, hs.ntt_data[0].data, sizeof(uint64_t) * wn);
		H[w] = ch;
		H[w + 1] = hs.ntt_data[1][1];
		while (H.size > 1 && H[H.size - 1] == 0)
			H.size--;
	}

	// 3. dst = C + B^N * H - H.  C is trimmed to <= N+2 <= total limbs and H to <= w+1
	//    (= total-N), but the copies are clamped anyway so the bounds are obvious to the
	//    compiler (and to a reader) instead of relying on the callers' preconditions.
	uint64_t cn = C.size < total ? C.size : total;
	uint64_t hn = H.size < total - N ? H.size : total - N;
	memset(dst, 0, sizeof(uint64_t) * total);
	memcpy(dst, C.data, sizeof(uint64_t) * cn);
	uint64_t carry = 0;
	for (uint64_t i = 0; i < hn; i++) {
		unsigned __int128 s = (unsigned __int128)dst[N + i] + H[i] + carry;
		dst[N + i] = (uint64_t)s;
		carry = (uint64_t)(s >> 64);
	}
	for (uint64_t i = hn; carry && N + i < total; i++) {
		unsigned __int128 s = (unsigned __int128)dst[N + i] + carry;
		dst[N + i] = (uint64_t)s;
		carry = (uint64_t)(s >> 64);
	}
	uint64_t borrow = 0;
	for (uint64_t i = 0; i < total; i++) {
		uint64_t s = i < H.size ? H[i] : 0;
		unsigned __int128 d = (unsigned __int128)dst[i] - s - borrow;
		dst[i] = (uint64_t)d;
		borrow = (uint64_t)(d >> 64) & 1;
	}
}
