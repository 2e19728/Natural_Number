#include <ctime>
#include <iostream>
#include <iomanip>
#include <chrono>	
#include "natural.h"
using namespace std;
using namespace chrono;

uint64_t ullrand() {
	return (uint64_t)rand() << 49 | (uint64_t)rand() << 34 | (uint64_t)rand() << 19 | (uint64_t)rand() << 4 | (uint64_t)rand() & 15;
}

uint64_t N = 1 << 24;

int main() {

	unsigned long start = 8388608;
	unsigned long end = 16777216;
	unsigned long step = 2097152;

	cout << fixed << setprecision(6);
	cout << "limbs,bits,time_sec,throughput_MiB_s\n";

	natural a, b, d;

	for (unsigned long n = start; n <= end; n += step) {
		a.resize(n);
		b.resize(n);
		for (int i = 0; i < a.size; i++)
			a[i] = ullrand();
		for (int i = 0; i < b.size; i++)
			b[i] = ullrand();
		d = a * b;

		auto t1 = high_resolution_clock::now();
		d = a * b;
		auto t2 = high_resolution_clock::now();

		double elapsed = duration<double>(t2 - t1).count();

		double data_mib = (double)(n * 2 * sizeof(uint64_t)) / (1024.0 * 1024.0);
		double throughput = data_mib / elapsed;

		unsigned long bits = n * 64;
		cout << n << "," << bits << "," << elapsed << "," << throughput << "\n";

		cout.flush();
	}


/*	natural a, b, d;
	clock_t t = 0;
	a.resize(N);
	b.resize(N);
	for (int i = 0; i < a.size; i++)
		a[i] = ullrand();
	for (int i = 0; i < b.size; i++)
		b[i] = ullrand();
	d = a * b;
	for (int i = 0; i < 5; i++) {
		t = clock();
		d = a * b;
		cerr << clock() - t << endl;
	}
	/*
		natural a, b, d, q, r;
		clock_t t;
		a.resize(N / 128 * 126);
		b.resize(N / 128 * 63);
		for (int i = 0; i < a.size; i++)
			a[i] = ullrand();
		for (int i = 0; i < b.size; i++)
			b[i] = ullrand();
		for (int i = 0; i < 2; i++) {
			t = clock();
			d = a / b;
			cerr << clock() - t << endl;
		}
		a.resize(N / 128 * 63);
		b.resize(N / 128 * 63);
		for (int i = 0; i < 2; i++) {
			t = clock();
			d = a * b;
			cerr << clock() - t << endl;
		}
	//*/
	/*/
		cin >> N;
		N = 1ull << N;
		natural a, b, d;
		a.resize(N);
		b.resize(N);
		for (int i = 0; i < N; i++)
			a[i] = ullrand(), b[i] = ullrand();
		clock_t t;
		for (int i = 0; i < 4; i++) {
			t = clock();
			d = a * b;
			cerr << hex << d[d.size - 1] << endl;
			cerr << dec << clock() - t << endl;
		}
	//*/
	/*/
		freopen("3_24_t.txt", "w", stdout);
		cout << hex << pow(natural(3), 1ull << 24) << endl;
	//*/
	/*
		natural num, den, q, r;
		clock_t t;

		t = clock();
		calc_e(num, den, 0, 1ull << 21);
		cerr << clock() - t << endl;

		t = clock();
		num *= pow(natural(10), 10000000);
		cerr << clock() - t << endl;

	//	calc_e(num, den, 0, 1ull << 27);
	//	num *= pow(natural(10), 1000000000);

		t = clock();
		num /= den;
		cerr << clock() - t << endl;

		freopen("e_10000000.txt", "w", stdout);
	//	freopen("e_1000000000.txt", "w", stdout);
	//	cout << num << endl;
		t = clock();
		cout << format("{}\n", num);
		cerr << clock() - t << endl;
	//*/
	/*
		natural num, den, numc, denc;
		clock_t t = clock();
		calc_pi(num, den, numc, 1, 1ull << 20 | 1);
		sqrt_10005(numc, denc, 600000);
		num = 0xcf6371 * den - num;
		den *= 0x68380 * numc * pow(natural(10), 10000000);
		num *= denc;
		den /= num;
		cerr << clock() - t << endl;
		freopen("pi_10000000_new.txt", "w", stdout);
		cout << dec << den << endl;
	//*/
	/*
		natural num, den, numc, denc;
		clock_t t = clock();
		calc_pi(num, den, numc, 1, 1ull << 23 | 1);
		sqrt_10005(numc, denc, 5200000);
		num = 0xcf6371 * den - num;
		den *= 0x68380 * numc * pow(natural(10), 100000000);
		num *= denc;
		den /= num;
		cerr << clock() - t << endl;
		freopen("pi_100000000.txt", "w", stdout);
		cout << dec << den << endl;
	//*/
	/*
		clock_t t = clock();
		natural f = factorial(10000000);
		cerr << clock() - t << endl;
		freopen("factorial_10000000.txt", "w", stdout);
		t = clock();
		cout << f << endl;
		cerr << clock() - t << endl;
	//*/

	/*
		int N = 256+128;
		natural a, b, d;
		a.resize(N);
		b.resize(N);

		clock_t t;

		t = clock();
		for (int i = 0; i < 10000; i++) {
			d._mul_base(&a, &b);
		}
		cerr << clock() - t << endl;

		t = clock();
		for (int i = 0; i < 10000; i++) {
			d._mul_NTT(&a, &b);
		}
		cerr << clock() - t << endl;
	//*/
}
