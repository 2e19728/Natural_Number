.intel_syntax noprefix
.text
.globl	mul_basecase_odd
mul_basecase_odd:
	push	rbx
	push	rbp
	push	r12
	push	r13
	push	r14
	push	r15
	# 洗牌: m=rdi n=rsi A=rdx B=rcx C=r8
	mov	rax, rdx		# rax = A
	mov	rbx, rcx		# rbx = B
	mov	rcx, r8			# rcx = C 游标
	lea	r8,  [rdi-1]		# r8  = m-1
	mov	r9,  rsi
	sub	r9,  rdi		# r9  = n-m
	# (0,0) 单列: 低肢(r10)->C[0]; 高肢(r12)右移1作列1窗口基 (r13..r15=0)
	mov	rdx, qword ptr [rax]	# A[0]
	mulx	r12, r10, qword ptr [rbx]	# r12=hi, r10=lo
	mov	qword ptr [rcx], r10	# C[0] = 低肢
	add	rcx, 8
	xor	r13d, r13d
	xor	r14d, r14d
	xor	r15d, r15d
# ================= 上升期: 轮 (1,2),(3,4),...,(m-2,m-1) =================
	mov	rbp, 1			# rbp = L = 1 (轮 (L,L+1))
L_rise_round:				# 关键点: rax=A基 rbx=B基 r8=m-1 r9=n-m
	mov	rdi, rbp		# i = L
	xor	esi, esi		# j = 0
	# peel: A[L+1]*B[0] (列 L+1 顶, 入 1 肢)
	mov	rdx, qword ptr [rax + rdi*8 + 8]
	mulx	r11, r10, qword ptr [rbx]
	add	r13, r10
	adc	r14, r11
	adc	r15, 0
L_rise_inner:				# U1: 单步 i 降 j 升; 步数 L+1 (奇)
	mov	rdx, qword ptr [rax + rdi*8]
	mulx	r11, r10, qword ptr [rbx + rsi*8]
	add	r12, r10
	adc	r13, r11
	mulx	r11, r10, qword ptr [rbx + rsi*8 + 8]
	adc	r11, 0
	add	r13, r10
	adc	r14, r11
	adc	r15, 0
	add	rsi, 1
	sub	rdi, 1
	jnc	L_rise_inner		# do-while, 借位退出 (含 i=0)
	# 存 C[L],C[L+1]; 窗口右移 2
	mov	qword ptr [rcx],     r12
	mov	qword ptr [rcx+8],   r13
	add	rcx, 16
	mov	r12, r14
	mov	r13, r15
	xor	r14d, r14d
	xor	r15d, r15d
	add	rbp, 2			# L += 2
	cmp	rbp, r8			# L < m-1 ?
	jb	L_rise_round
	# 上升结束: 窗口对齐列 m-1
# ================= 平台期: 全长列 m..n-1 (少一列; 首轮 B 起点 B[1]) =================
	add	rbx, 8			# B 起点 = &B[1] (列 m 最低 B 下标 = 1)
	cmp	r9, 2
	jb	L_plat_done		# D<2: 无配对轮 (D=0/1)
L_plat_round:				# 轮 (L,L+1), L = m+2t
	mov	rdi, r8			# i = m-1
	xor	esi, esi		# j = 0 (局部; 实际 B 下标 = (2t+1)+j)
L_plat_inner:				# U1: 单步; 步数 m (奇)
	mov	rdx, qword ptr [rax + rdi*8]
	mulx	r11, r10, qword ptr [rbx + rsi*8]
	add	r12, r10
	adc	r13, r11
	mulx	r11, r10, qword ptr [rbx + rsi*8 + 8]
	adc	r11, 0
	add	r13, r10
	adc	r14, r11
	adc	r15, 0
	add	rsi, 1
	sub	rdi, 1
	jnc	L_plat_inner
	mov	qword ptr [rcx],     r12
	mov	qword ptr [rcx+8],   r13
	add	rcx, 16
	mov	r12, r14
	mov	r13, r15
	xor	r14d, r14d
	xor	r15d, r15d
	add	rbx, 16			# B 起点 +2 肢
	sub	r9, 2
	cmp	r9, 2
	jae	L_plat_round		# 剩余 D'>=2 继续
L_plat_done:
	test	r9, 1
	jz	L_fall_prep		# D 偶: 平台全配对, 无剩余列
	# ---- 剩余列 n-1 (D 奇): rbx 现 = &B[D] = &B[n-m], 局部 j 0..m-1 ----
	mov	rdi, r8			# i = m-1
	xor	esi, esi		# j = 0
L_left_inner:				# 单积入 0 肢 (i+j = n-1)
	mov	rdx, qword ptr [rax + rdi*8]
	mulx	r11, r10, qword ptr [rbx + rsi*8]
	add	r12, r10
	adc	r13, r11
	adc	r14, 0
	add	rsi, 1
	sub	rdi, 1
	jnc	L_left_inner
	mov	qword ptr [rcx], r12	# C[n-1]
	add	rcx, 8
	mov	r12, r13		# 右移 1 -> 对齐列 n
	mov	r13, r14
	xor	r14d, r14d
	add	rbx, 8
L_fall_prep:
	lea	rax, [rax + r8*8 + 8]	# rax = A + m*8 (负索引基)
	lea	rbx, [rbx + r8*8]	# rbx = B + n*8
	mov	rbp, 1
	sub	rbp, r8			# rbp = i0 = 2-m = -(m-2)
L_fall_outer:				# 轮: 列对 (m+n+i0-2, m+n+i0-1)
	mov	rdi, rbp		# i = i0
	mov	rsi, -1			# j = -1
	# peel: A'[i0-1] * B'[-1] (列 L 底, 入 0 肢)
	mov	rdx, qword ptr [rax + rdi*8 - 8]
	mulx	r11, r10, qword ptr [rbx - 8]
	add	r12, r10
	adc	r13, r11
	adc	r14, 0
L_fall_inner:				# U1: i 升 / j 降; 步数 m-2t-2 (奇)
	mov	rdx, qword ptr [rax + rdi*8]
	mulx	r11, r10, qword ptr [rbx + rsi*8 - 8]
	add	r12, r10
	adc	r13, r11
	mulx	r11, r10, qword ptr [rbx + rsi*8]
	adc	r11, 0
	add	r13, r10
	adc	r14, r11
	adc	r15, 0
	sub	rsi, 1
	add	rdi, 1
	js	L_fall_inner		# 继续 while i<0 (js 测 add rdi,1 的符号位)
	mov	qword ptr [rcx],     r12
	mov	qword ptr [rcx+8],   r13
	add	rcx, 16
	mov	r12, r14
	mov	r13, r15
	xor	r14d, r14d
	xor	r15d, r15d
	add	rbp, 2			# i0 += 2
	js	L_fall_outer		# i0 = -1 后 +2 -> 1 退出 (m 奇全配对)
	# ---- 顶肢 C[m+n-1] = w0 (无独立尾积) ----
	mov	qword ptr [rcx], r12
	pop	r15
	pop	r14
	pop	r13
	pop	r12
	pop	rbp
	pop	rbx
	ret
.section .note.GNU-stack,"",@progbits
